package Week10;

public class Lion extends Animal
{
    public void eat()
    {
        System.out.println("Lion eating");
    }

    public void move()
    {
        System.out.println("Lion can move very fast");
    }

    public void hunt()
    {
        System.out.println("Lion hunt to feed themselves");
    }

}
