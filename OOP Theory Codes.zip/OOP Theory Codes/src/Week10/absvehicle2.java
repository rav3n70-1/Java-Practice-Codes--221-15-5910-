package Week10;

public abstract class absvehicle2 {
    public absvehicle2()
    {
        System.out.println("Vehicle here");
    }
    public abstract void move();

    public void carry()
    {
        System.out.println("Carrying Cows");
    }
}

class kar extends absvehicle2
{
    @Override
    public void move()
    {
        System.out.println("Car is moving faster");
    }
}

class Boat extends absvehicle2
{
    @Override
    public void move()
    {
        System.out.println("Boat is moving");
    }
}
