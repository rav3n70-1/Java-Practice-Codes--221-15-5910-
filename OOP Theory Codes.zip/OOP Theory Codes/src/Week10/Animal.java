package Week10;

public class Animal {
    public void eat() {
	}

    public void move() {
	}

    public void life()
    {
        System.out.println("Life is Beautiful");
    }
}
