package Week10;

public class Human extends Animal
{
    public void eat()
    {
        System.out.println("Human is eating Burger");
    }

    public void move()
    {
        System.out.println("Human moves slowly");
    }

    public void talk()
    {
        System.out.println("Human can talk");
    }
}
