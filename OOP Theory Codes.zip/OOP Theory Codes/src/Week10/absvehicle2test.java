package Week10;

public class absvehicle2test {
	
	    public static void main(String[] args)
	    {
	        kar car = new kar ();
	        car.move();
	        car.carry();

	        Boat boat = new Boat();
	        boat.move();
	        boat.carry();

	    }
	}
