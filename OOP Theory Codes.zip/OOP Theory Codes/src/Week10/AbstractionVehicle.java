package Week10;

public abstract class AbstractionVehicle
{
    public AbstractionVehicle()
    {
        System.out.println("Vehicle Constructor");
    }
    public abstract void move();

    public void carry()
    {
        System.out.println("Carrying Eggs");
    }
}

class Car extends AbstractionVehicle
{
    @Override
    public void move()
    {
        System.out.println("Car is moving");
    }

    public static void main(String[] args)
    {
        Car car = new Car();

        car.move();
        car.carry();
    }
}
