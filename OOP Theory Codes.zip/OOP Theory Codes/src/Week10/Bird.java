package Week10;

public class Bird extends Animal
{
    public void eat()
    {
        System.out.println("Bird is eating");
    }

    public void move()
    {
        System.out.println("Bird is flying");
    }

    public void fly()
    {
        System.out.println("Bird can fly for a long time");
    }
}
