package Week3;

public class TestClass {
	 public static void main(String[] args)
	    {
	        int x, y;

	        for (x = 0; x < 5; x++)
	        {
	            for (y = 5; y > 0; y--)
	                System.out.println("*");
	            System.out.print("\n");
	        }
	    }
	}
