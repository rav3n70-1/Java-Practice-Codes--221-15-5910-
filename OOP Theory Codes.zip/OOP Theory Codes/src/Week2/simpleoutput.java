package Week2;

public class simpleoutput {
	    public static void main(String[] args)
	    {
	        int a = 10, b;

	        b = (a==1) ? 20 : 30;
	        {
	            System.out.println("Value of b is " + b);
	        }

	        b = (a==10) ? 20 : 30;
	        {
	            System.out.println("Value of b is " + b);
	        }
	    }

}
