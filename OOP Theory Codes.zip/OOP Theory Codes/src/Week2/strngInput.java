package Week2;
import java.util.Scanner;
public class strngInput {
	public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your name");
        String name = sc.nextLine();

        System.out.println("Name is : " + name);

    }

}
