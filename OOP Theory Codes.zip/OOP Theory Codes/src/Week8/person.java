package Week8;

public class person {
    protected String name;
    protected int age;

    public person(String name, int age)
    {
        this.name = name;
        this.age = age;
    }
    public void display ()
    {
        System.out.println("Name is " + name);
        System.out.println("Age is " + age);
    }
}
