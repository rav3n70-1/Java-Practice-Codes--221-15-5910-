package Week8;

public class student extends person
{
    private int id;
    private double cgpa;

    public student (String name, int age, int id, double cgpa)
    {
        super(name, age);
        this.id = id;
        this.cgpa = cgpa;
    }

    public void display ()
    {
        super.display();
        System.out.println("ID is " + id);
        System.out.println("CGPA is " + cgpa);
    }

    public static void main(String[] args)
    {
        student st = new student("Rohan", 22, 221, 2.50 );
        st.display();

    }
}
