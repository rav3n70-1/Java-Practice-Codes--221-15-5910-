package Week8;

 public class student1 extends person1
{
    private int id;
    private double cgpa;

    public void display ()
    {
        System.out.println("Name is " + name);
        System.out.println("Age is " + age);
        System.out.println("ID is " + id);
        System.out.println("CGPA is " + cgpa);
    }

    public static void main(String[] args)
    {
        student1 st = new student1();
        st.name = "Rohan";
        st.age = 20;
        st.id = 221;
        st.cgpa = 2.69;
        st.display();

    }
}
