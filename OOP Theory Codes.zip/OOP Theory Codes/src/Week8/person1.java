package Week8;

public class person1 {
    protected String name;
    protected int age;
}
