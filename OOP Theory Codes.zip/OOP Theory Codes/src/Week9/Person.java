package Week9;

public class Person {
    protected String name = "Rohan";
    protected int age = 20;
}

class Student extends Person
{
    private int id = 5910;
    private double cgpa = 2.85;

    public void display ()
    {
        System.out.println("Name " + name);
        System.out.println("Age " + age);
        System.out.println("Id " + id);
        System.out.println("CGPA" + cgpa);
    }

    public static void main(String[] args) {
        Student st = new Student();
        st.display();
    }
}
