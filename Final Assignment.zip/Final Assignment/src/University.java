
public class University
{
    public static void main(String[] args)
    {
        Employee [] arrEmployee = new Employee[3];
        arrEmployee[0] = new Professor(1, "Rohan", 800.15, "Law");
        arrEmployee[1] = new Administrator(2, "Riyad", 700.95, "Software");
        arrEmployee[2] = new SupportStaff(3, "Rafi", 500.12, "Manager");

        for (Employee employee : arrEmployee)
        {
            System.out.println(employee.toString() );
        }

        double totalSalary = Employee.totalSalary(arrEmployee);
        System.out.println("\nTotal salary: " + totalSalary);
    }
}
